# encoding: UTF-8
# frozen_string_literal: true
# This file is auto-generated from the current state of VCS.
# Instead of editing this file, please use bin/gendocs.

module Peatio
  class Application
    GIT_TAG =    '1.9.19'
    GIT_SHA =    '5975f0a'
    BUILD_DATE = 'Tue Jan 29 21:21:31 UTC 2019'
    VERSION =    GIT_TAG
  end
end
