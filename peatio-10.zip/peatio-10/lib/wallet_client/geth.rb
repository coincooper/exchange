# encoding: UTF-8
# frozen_string_literal: true

module WalletClient
  class Geth < Ethereum
    
  end
end
