# encoding: UTF-8
# frozen_string_literal: true

module WalletClient
  class Parity < Ethereum
    
  end
end
