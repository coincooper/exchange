# encoding: UTF-8
# frozen_string_literal: true

module BlockchainClient
  class Geth < Ethereum

  end
end
